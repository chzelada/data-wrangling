

df1 <- read_excel("01-2017.xlsx")
df1$Fecha<- c("01-2017")
df1

df2 <- read_excel("02-2017.xlsx")
df2$Fecha<- c("02-2017")
df2

df3 <- read_excel("03-2017.xlsx")
df3$Fecha<- c("03-2017")
df3

df4 <- read_excel("04-2017.xlsx")
df4$Fecha<- c("04-2017")
df4

df5 <- read_excel("05-2017.xlsx")
df5$Fecha<- c("05-2017")
df5

df6 <- read_excel("06-2017.xlsx")
df6$Fecha<- c("06-2017")
df6

df7 <- read_excel("07-2017.xlsx")
df7$Fecha<- c("07-2017")
df7 <- subset( df7, select = -TIPO )
df7

df8 <- read_excel("08-2017.xlsx")
df8$Fecha<- c("08-2017")
df8 <- subset( df8, select = -TIPO )
df8 <- subset( df8, select = -X__1 )
df8

df9<- read_excel("09-2017.xlsx")
df9$Fecha<- c("09-2017")
df9 <- subset( df9, select = -TIPO )
df9

df10 <- read_excel("10-2017.xlsx")
df10$Fecha<- c("10-2017")
df10 <- subset( df10, select = -TIPO )
df10

df11 <- read_excel("11-2017.xlsx")
df11$Fecha<- c("11-2017")
df11 <- subset( df11, select = -TIPO )
df11

dfinal <- rbind(df1,df2)
dfinal <- rbind(dfinal,df3)
dfinal <- rbind(dfinal,df4)
dfinal <- rbind(dfinal,df5)
dfinal <- rbind(dfinal,df6)
dfinal <- rbind(dfinal,df7)
dfinal <- rbind(dfinal,df8)
dfinal <- rbind(dfinal,df9)
dfinal <- rbind(dfinal,df10)
dfinal <- rbind(dfinal,df11)


write.xlsx(dfinal, file="Lab1.xlsx", sheetName="Lab1")
