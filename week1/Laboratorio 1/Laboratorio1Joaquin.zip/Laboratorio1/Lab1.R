
install.packages("readxl")
library(readxl)  
enero <- read_excel("Laboratorio 1/01-2017.xlsx")
febrero <- read_excel("Laboratorio 1/02-2017.xlsx")
marzo<- read_excel("Laboratorio 1/03-2017.xlsx")
abril <- read_excel("Laboratorio 1/04-2017.xlsx")
mayo <- read_excel("Laboratorio 1/05-2017.xlsx")
junio <- read_excel("Laboratorio 1/06-2017.xlsx")
julio <- read_excel("Laboratorio 1/07-2017.xlsx")
agosto <- read_excel("Laboratorio 1/08-2017.xlsx")
septiembre <- read_excel("Laboratorio 1/09-2017.xlsx")
octubre <- read_excel("Laboratorio 1/10-2017.xlsx")
noviembre <- read_excel("Laboratorio 1/11-2017.xlsx")

merge <- rbind(enero,febrero,marzo,abril,mayo,junio,julio,agos,septiembre,octubre,noviembre)


agos <- agosto[,c(1:9)]


mayo$Fecha <- "05-2017"
marzo$Fecha <- "03-2017"
junio$Fecha <- "06-2017"
enero$Fecha <- "01-2017"
febrero$Fecha <- "02-2017"
abril$Fecha <- "04-2017"

julio <- julio[,-9]
julio$Fecha<- "07-2017"
agos <- agos[,-9]
agos$Fecha <- "08-2017"
septiembre <- septiembre[,-9]
septiembre$Fecha <- "09-2017"
octubre <- octubre[,-9]
octubre$Fecha<- "10-2017"
noviembre <- noviembre[,-9]
noviembre$Fecha<-"11-2017"


write.csv(merge, file = "laboratorio.csv")
