library("dplyr")
library("readr")
library("readxl")
a <- read_excel("01-2017.xlsx")
a["Fecha"]<- "01-2017"
toDelete <- c("TIPO","X__1")
a <- a[, !(names(a) %in% toDelete)]

c <- read_excel("09-2017.xlsx")
#7 tiene 9 columnas
#8 tiene 10
c
for(i in 2:11)
{
  if(i<10)
  {
    fe <- paste("0",i,"-2017",sep="")
    b<-read_excel(paste(fe,".xlsx",sep=""))
    b <- b[, !(names(b) %in% toDelete)]
    b["Fecha"]<-fe
    
  }
  else
  {
    fe <- paste(i,"-2017",sep="")
    b<-read_excel(paste(fe,".xlsx",sep=""))
    b <- b[, !(names(b) %in% toDelete)]
    b["Fecha"]<-fe
  }
  a<-rbind(a,b)
}
write.csv(a,"year.csv")