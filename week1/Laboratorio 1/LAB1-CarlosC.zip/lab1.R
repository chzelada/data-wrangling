
arch1 <- read_excel("01-2017.xlsx")
arch2 <- read_excel("02-2017.xlsx")
arch3 <- read_excel("03-2017.xlsx")
arch4 <- read_excel("04-2017.xlsx")
arch5 <- read_excel("05-2017.xlsx")
arch6 <- read_excel("06-2017.xlsx")
arch7 <- read_excel("07-2017.xlsx")
arch8 <- read_excel("08-2017.xlsx")
arch9 <- read_excel("09-2017.xlsx")
arch10 <- read_excel("10-2017.xlsx")
arch11 <- read_excel("11-2017.xlsx")


arch6 <- arch6[,c(1:8)]
arch7 <- arch7[,c(1:8)]
arch8 <- arch8[,c(1:8)]
arch9 <- arch9[,c(1:8)]
arch10 <- arch10[,c(1:8)]
arch11 <- arch11[,c(1:8)]

arch1$Fecha <- '01-2017'
arch2$Fecha <- '02-2017'
arch3$Fecha <- '03-2017'
arch4$Fecha <- '04-2017'
arch5$Fecha <- '05-2017'
arch6$Fecha <- '06-2017'
arch7$Fecha <- '07-2017'
arch8$Fecha <- '08-2017'
arch9$Fecha <- '09-2017'
arch10$Fecha <- '10-2017'
arch11$Fecha <- '11-2017'

install.packages("WriteXLS")
library("WriteXLS")
#remove.packages( "xlsx")
Laboratorio1 <- rbind(arch1, arch2, arch3, arch4, arch5, arch6, arch7, arch8, arch9, arch10, arch11 )
WriteXLS(Laboratorio1 , ExcelFileName = "Laboratorio1.xlsx", SheetNames = "Clientes", BoldHeaderRow = TRUE)


