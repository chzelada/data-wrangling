library(readr)
library(readxl)

dfr1 = read_excel("./Folder/01-2017.xlsx")
dfr2 = read_excel("./Folder/02-2017.xlsx")
dfr3 = read_excel("./Folder/03-2017.xlsx")
dfr4 = read_excel("./Folder/04-2017.xlsx")
dfr5 = read_excel("./Folder/05-2017.xlsx")
dfr6 = read_excel("./Folder/06-2017.xlsx")
dfr7 = read_excel("./Folder/07-2017.xlsx")
dfr8 = read_excel("./Folder/08-2017.xlsx")
dfr9 = read_excel("./Folder/09-2017.xlsx")
dfr10 = read_excel("./Folder/10-2017.xlsx")
dfr11 = read_excel("./Folder/11-2017.xlsx")

s1 <- dfr1[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s2 <- dfr2[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s3 <- dfr3[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s4 <- dfr4[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s5 <- dfr5[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s6 <- dfr6[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s7 <- dfr7[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s8 <- dfr8[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s9 <- dfr9[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s10 <- dfr10[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]
s11 <- dfr11[c("COD_VIAJE","CLIENTE","UBICACION","CANTIDAD","PILOTO","Q","CREDITO","UNIDAD")]

s1$fecha <- "01-2017"
s2$fecha <- "02-2017"
s3$fecha <- "03-2017"
s4$fecha <- "04-2017"
s5$fecha <- "05-2017"
s6$fecha <- "06-2017"
s7$fecha <- "07-2017"
s8$fecha <- "08-2017"
s9$fecha <- "09-2017"
s10$fecha <- "10-2017"
s11$fecha <- "11-2017"


prueba <- rbind(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11)

write.csv(prueba, file = "Lab1_NathaliaMorales.csv")
