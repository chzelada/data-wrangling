install.packages("dplyr")
install.packages("data.table")
library("readxl")
library("dplyr")
library("data.table")

tabla1 <- read_excel("01-2017.xlsx",head(1))
T1 <- select(tabla1, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla2 <- read_excel("02-2017.xlsx",head(1))
T2 <- select(tabla2, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla3 <- read_excel("03-2017.xlsx",head(1))
T3 <- select(tabla3, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla4 <- read_excel("04-2017.xlsx",head(1))
T4 <- select(tabla4, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla5 <- read_excel("05-2017.xlsx",head(1))
T5 <- select(tabla5, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla6 <- read_excel("06-2017.xlsx",head(1))
T6 <- select(tabla6, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla7 <- read_excel("07-2017.xlsx",head(1))
T7 <- select(tabla7, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla8 <- read_excel("08-2017.xlsx",head(1))
T8 <- select(tabla8, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla9 <- read_excel("09-2017.xlsx",head(1))
T9 <- select(tabla9, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla10 <- read_excel("10-2017.xlsx",head(1))
T10 <- select(tabla10, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 
tabla11 <- read_excel("11-2017.xlsx",head(1))
T11 <- select(tabla11, COD_VIAJE, CLIENTE, UBICACION, CANTIDAD, PILOTO, Q 
             ,CREDITO,UNIDAD) 

T1$FECHA1 <- ("01-2017")
T2$FECHA1 <- ("02-2017")
T3$FECHA1 <- ("03-2017")
T4$FECHA1 <- ("04-2017")
T5$FECHA1 <- ("05-2017")
T6$FECHA1 <- ("06-2017")
T7$FECHA1 <- ("07-2017")
T8$FECHA1 <- ("08-2017")
T9$FECHA1 <- ("09-2017")
T10$FECHA1 <- ("10-2017")
T11$FECHA1 <- ("11-2017")

TablaFinal <- rbind(T1, T2,T3, T4, T5, T6, T7,T8, T9,  T10, T11)
write.csv(TablaFinal, file = "Laboratorio1.csv")
