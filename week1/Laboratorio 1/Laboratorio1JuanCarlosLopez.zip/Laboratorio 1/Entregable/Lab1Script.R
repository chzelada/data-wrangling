install.packages('xlsx')
install.packages('tidyr')
library(tidyr)
library(xlsx)
D1 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/01-2017.xlsx', 1)
D2 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/02-2017.xlsx', 1)
D3 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/03-2017.xlsx', 1)
D4 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/04-2017.xlsx', 1)
D5 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/05-2017.xlsx', 1)
D6 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/06-2017.xlsx', 1)
D7 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/07-2017.xlsx', 1)
D8 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/08-2017.xlsx', 1)
D9 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/09-2017.xlsx', 1)
D10 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/10-2017.xlsx', 1)
D11 <- read.xlsx('C:/Users/chino/Desktop/Laboratorio 1/11-2017.xlsx', 1)
D7 <- subset(D7, select = -c(TIPO))
D8 <- subset(D8, select = -c(TIPO, NA.))
D9 <- subset(D9, select = -c(TIPO))
D10 <- subset(D10, select = -c(TIPO))
D11 <- subset(D11, select = -c(TIPO))
D1["Fecha"] <- '01-2017'
D2["Fecha"] <- '02-2017'
D3["Fecha"] <- '03-2017'
D4["Fecha"] <- '04-2017'
D5["Fecha"] <- '05-2017'
D6["Fecha"] <- '06-2017'
D7["Fecha"] <- '07-2017'
D8["Fecha"] <- '08-2017'
D9["Fecha"] <- '09-2017'
D10["Fecha"] <- '10-2017'
D11["Fecha"] <- '11-2017'
final <- rbind(D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11)
library(tidyr)
final <- final %>% drop_na()
write.csv(final, "Lab1.csv")
