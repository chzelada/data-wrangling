#### LAB O1 ####

library (readxl)

# importar archivos
en <- read_excel("01-2017.xlsx")
fe <- read_excel("02-2017.xlsx")
mr <- read_excel("03-2017.xlsx")
ab <- read_excel("04-2017.xlsx")
ma <- read_excel("05-2017.xlsx")
jn <- read_excel("06-2017.xlsx")
jl <- read_excel("07-2017.xlsx")
ag <- read_excel("08-2017.xlsx")
se <- read_excel("09-2017.xlsx")
oc <- read_excel("10-2017.xlsx")
nv <- read_excel("11-2017.xlsx")


# añadir columna de fecha
en$fecha <- c('01-2017')
fe$fecha <- c('02-2017')
mr$fecha <- c('03-2017')
ab$fecha <- c('04-2017')
ma$fecha <- c('05-2017')
jn$fecha <- c('06-2017')
jl$fecha <- c('07-2017')
ag$fecha <- c('08-2017')
se$fecha <- c('09-2017')
oc$fecha <- c('10-2017')
nv$fecha <- c('11-2017')



#examinar archivos
# Al hacerlo con cada mes vi que Ag tiene una variable mas que Jl, Se, Oc y Nov, y estas ultimas tienen una mas que los emses restantes
length(names(nv))

#list.files("/users/pQ5Xttu8/Desktop/Data Warngling/Laboratorio 1")

NROW(en)
NROW(fe)
NROW(mr)

months_a <- rbind(en, fe, mr, ab, ma, jn)
months_b <- rbind(jl, se, oc, nv)

pivot_months <- rbind(months_a, months_b[, names(months_a)])

months <- rbind(pivot_months, ag[, names(pivot_months)])

length(names(months))
nrow(months)
head(months)

write.csv(months, file="Resultado")

