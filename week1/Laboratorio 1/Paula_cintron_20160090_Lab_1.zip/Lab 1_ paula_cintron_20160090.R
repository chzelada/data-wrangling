library(readxl)
#leer todos los meses y todos los archivos
enero<-read_excel("01-2017.xlsx")
febrero<-read_excel("02-2017.xlsx")
marzo<-read_excel("03-2017.xlsx")
abril<-read_excel("04-2017.xlsx")
mayo<-read_excel("05-2017.xlsx")
junio<-read_excel("06-2017.xlsx")
julio<-read_excel("07-2017.xlsx")
agosto<-read_excel("08-2017.xlsx")
septiembre<-read_excel("09-2017.xlsx")
octubre<-read_excel("10-2017.xlsx")
noviemrbe<-read_excel("11-2017.xlsx")

#como jalar todas en una sola tabla?
install.packages(car)
as.table(enero)
list.files(path="")

#subste: quitar 
#b agregar columnas a tablas

#agregar fechas 
b["fecha"]<-fecha

#agregue columna fecha
enero["fecha"]<-"01-2017"

#variable de columnas a eliminar
todelete<- c("TIPO","X__1")

#elimine las columnas de enero que quiero eliminar
enero<-enero[,!(names(enero)%in% todelete)] 

#hice un ciclo, 
for (i in 2:11) 
  {
   if(i<10)
   {fecha<- paste("0", i, "-2017", sep="")}

  else
  {fecha<- paste(i, "-2017", sep = "") }
  
mes<-read_excel(paste(fecha,".xlsx", sep=""))
mes<-mes[,!(names(mes) %in% todelete)]
mes["fecha"]<-fecha
enero<-rbind(enero,mes)

}

#nuevo nombre del archivo
write.csv(enero, "year_2017.csv")

#
year_2017<-enero 









