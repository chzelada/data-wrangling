install.packages("readxl")
library(readxl)
file1 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/01-2017.xlsx")
View(file2)
file2 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/02-2017.xlsx")
file3 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/03-2017.xlsx")
file4 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/04-2017.xlsx")
file5 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/05-2017.xlsx")
file6 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/06-2017.xlsx")
file7 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/07-2017.xlsx")
file8 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/08-2017.xlsx")
file9 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/09-2017.xlsx")
file10 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/10-2017.xlsx")
file11 <- read_excel("~/U/Semestre 12/Data/Laboratorio 1/11-2017.xlsx")
file1$fecha<-c("01-2017")
file2$fecha<-c("02-2017")
file3$fecha<-c("03-2017")
file4$fecha<-c("04-2017")
file5$fecha<-c("05-2017")
file6$fecha<-c("06-2017")
mydata<-rbind(file1,file2,file3,file4,file5,file6)
file7$TIPO<-NULL
file7$fecha<-c("07-2017")
file8$TIPO<-NULL
file8$X__1<-NULL
file8$fecha<-c("08-2017")
file9$TIPO<-NULL
file9$fecha<-c("09-2017")
file10$TIPO<-NULL
file10$fecha<-c("10-2017")
file11$TIPO<-NULL
file11$fecha<-c("11-2017")
mydata<-rbind(file1,file2,file3,file4,file5,file6,file7,file8,file9,file10,file11)
write.csv(mydata, "~/U/Semestre 12/Data/Laboratorio 1/mydata.csv")