#Rodrigo Cano - 20150025
#Lab 1 

#install dependencies
install.packages("readr")
library(readr)
install.packages("readxl")
library(readxl)

#load files and add column with date

toDelete <- c("TIPO","X__1")

jan <- read_excel("Laboratorio 1/01-2017.xlsx")
jan["fecha"] <- "01-2017" 

feb <- read_excel("Laboratorio 1/02-2017.xlsx")
feb["fecha"] <- "02-2017" 

mar <- read_excel("Laboratorio 1/03-2017.xlsx")
mar["fecha"] <- "03-2017" 

apr <- read_excel("Laboratorio 1/04-2017.xlsx")
apr["fecha"] <- "04-2017" 

may <- read_excel("Laboratorio 1/05-2017.xlsx")
may["fecha"] <- "05-2017" 

jun <- read_excel("Laboratorio 1/06-2017.xlsx")
jun["fecha"] <- "06-2017"

jul <- read_excel("Laboratorio 1/07-2017.xlsx")
jul <- jul[, !(names(jul) %in% toDelete)]
jul["fecha"] <- "07-2017"

ago <- read_excel("Laboratorio 1/08-2017.xlsx")
ago <- ago[, !(names(ago) %in% toDelete)]
ago["fecha"] <- "08-2017"

sep <- read_excel("Laboratorio 1/09-2017.xlsx")
sep <- sep[, !(names(sep) %in% toDelete)]
sep["fecha"] <- "09-2017"

oct <- read_excel("Laboratorio 1/10-2017.xlsx")
oct <- oct[, !(names(oct) %in% toDelete)]
oct["fecha"] <- "10-2017"

nov <- read_excel("Laboratorio 1/11-2017.xlsx")
nov <- nov[, !(names(nov) %in% toDelete)]
nov["fecha"] <- "11-2017"

#joining all dataframes

year <- do.call("rbind",list(jan,feb,mar,apr,may,jun,jul,ago,sep,oct,nov))

#writing csv

write.csv(year,"year.csv")

