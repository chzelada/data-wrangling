#install.packages("readxl")
library(readxl)
getwd()
#setwd(".../Data Wragling/Laboratorio 1")

#readxl_example()
#rm(archivo)

f1<-"01-2017" 
f2<-"02-2017" 
f3<-"03-2017" 
f4<-"04-2017"
f5<-"05-2017"
f6<-"06-2017"
f7<-"07-2017"
f8<-"08-2017"
f9<-"09-2017"
f10<-"10-2017"
f11<-"11-2017"

archivo1 <- read_excel("01-2017.xlsx", range= cell_cols("A:H"))
archivo1["Fecha"]<- f1
head(archivo1)
#write.table(archivo1,file="archi1.csv", sep=";", dec=".", row.names = FALSE)
#write.csv2(archivo1, file = "arch1-1.csv")
#rm(archivo1)

archivo2 <- read_excel("02-2017.xlsx", range= cell_cols("A:H"))
archivo2["Fecha"]<- f2
head(archivo2)

archivo3 <- read_excel("03-2017.xlsx", range= cell_cols("A:H"))
archivo3["Fecha"]<- f3
head(archivo3)

archivo4 <- read_excel("04-2017.xlsx", range= cell_cols("A:H"))
archivo4["Fecha"]<- f4

archivo5 <- read_excel("05-2017.xlsx", range= cell_cols("A:H"))
archivo5["Fecha"]<- f5

archivo6 <- read_excel("06-2017.xlsx", range= cell_cols("A:H"))
archivo6["Fecha"]<- f6

archivo7 <- read_excel("07-2017.xlsx", range= cell_cols("A:H"))
archivo7["Fecha"]<- f7

archivo8 <- read_excel("08-2017.xlsx", range= cell_cols("A:H"))
archivo8["Fecha"]<- f8

archivo9 <- read_excel("09-2017.xlsx", range= cell_cols("A:H"))
archivo9["Fecha"]<- f9

archivo10 <- read_excel("10-2017.xlsx", range= cell_cols("A:H"))
archivo10["Fecha"]<- f10

archivo11 <- read_excel("11-2017.xlsx", range= cell_cols("A:H"))
archivo11["Fecha"]<- f11

#rm(archivo1, archivo2, archivo3, archivo4,archivo5, archivo6, archivo7, archivo8, archivo9, archivo10, archivo11)
#warnings()

#str(archivo8)
#head(archivo8, 7)

archivo_final <- rbind(archivo1, archivo2, archivo3, archivo4, archivo5, archivo6, archivo7, archivo8, archivo9, archivo10, archivo11)
head(archivo_final)

write.table(archivo_final,file="Datos_Unificados.csv", sep=";", dec=".", row.names = FALSE)

head(archivo_final)

save.image("lab1.RData")
