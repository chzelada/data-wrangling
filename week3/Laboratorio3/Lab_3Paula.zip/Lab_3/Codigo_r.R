
library("dplyr")
library("readr")
library("ggplot2")
library("tidyr")
install.packages("RPostgreSQL")
library("RMySQL")
install.packages("lubridate")
library("lubridate")

#documento laboratorio 1 
year_2017<- read.csv("year_2017.csv")

library(readr)
year_2017 <- read_csv("Documents/data/semana 1/laboratorio 1/year_2017.csv")
View(year_2017)

### (1)¿Debemos invertir en la contratación de más personal?

#promedio de viajes por piloto al año

year_2017%>%
  select(PILOTO)%>%
  group_by(PILOTO)%>%
  summarise(viajes=n())%>%
  mutate(mean(viajes))
  
#porcentaje de viajes por cada piloto al año

piloto_promedio=year_2017%>%
  select(PILOTO)%>%
  group_by(PILOTO)%>%
  summarise(viajes=n())%>%
  mutate(mean(viajes)/2180)
  

### (3) Las tarifas actuales ¿son aceptables por el cliente? 

#distribución de producto por cliente


Insatisfecho =year_2017 %>%
  select(CLIENTE)%>%
  group_by(CLIENTE)%>%
  summarise(insatisfecho=n())%>%
  mutate(insatisfecho/2180)%>%
  arrange(desc(insatisfecho))




#separar columna CLIENTE de la variable Despachado a cliente 

y=year_2017%>% separate(CLIENTE,into =c("Cliente","despachado"), sep="/")


                 
#analizar cuantos han sido despachados

y %>%
  select(Cliente,despachado)%>%
  group_by(Cliente, despachado)%>%
  summarise(despacho=n())%>%
  mutate(despacho/2180)



#cantidad de clientes insatisfechos = con marca "faltante" o "devolucion"

year_2017%>%
  select(CLIENTE)%>%
  group_by(CLIENTE)%>%
  summarise(insatisfecho=n())%>%
  mutate(insatisfecho/2180)

  
### (6) Mejores pilotos y transportes más efectivos.

#ver la cantidad y porcentaje de viajes por piloto
  
year_2017%>%
  select(PILOTO)%>%
  group_by(PILOTO)%>%
  summarise(viajes=n())%>%
  mutate(pilas=viajes/2180)%>%
  arrange(desc(pilas))

#principales pilotos por cliente segun numero de viajes en el año

year_2017%>%
  select(PILOTO, CLIENTE)%>%
  group_by(CLIENTE, PILOTO)%>%
  summarise(viajes=n())%>%
  arrange(desc(CLIENTE,viajes))


#cantidad de viajes por unidad de vehiculo

unidad=year_2017%>%
  select(UNIDAD)%>%
  group_by(UNIDAD)%>%
  summarise(viajes=n())%>%
  mutate(viajes/2180)

### (4) ¿Nos están robando los pilotos?

#determinar el precio por lata 

year_2017%>%
  select(Q,CANTIDAD)%>%
  mutate(precio_x_lata= Q/CANTIDAD)%>%
  arrange(precio_x_lata)

#precio por lata, no nos estan robando cantidad de veces

year_2017%>%
  select(Q,CANTIDAD)%>%
  mutate(precio_x_lata= Q/CANTIDAD)%>%
  summarise(precio_x_lata=n())

#cantidad de producto despachado por cliente


  








  
