library(readr)
Laboratorio1 <- read_csv("Laboratorio1.csv")
Lab1 <- as.data.frame(Laboratorio1)
View(Lab1)

head(Lab1)
library(RMySQL)
library(dplyr)


pilotos <- Lab1 %>% count(PILOTO, sort = TRUE)
pilotos


# 4
Robando <- Lab1 %>%
  mutate(Test = CANTIDAD/Q) %>%
  filter((Test < 4) && (Test>4))
CantidadRobos<-count(Robando)    
CantidadRobos

#2 

CAMIONES <- select(Lab1, UNIDAD) %>% group_by(UNIDAD)  %>% summarise(PORCENTAJE =length(UNIDAD)/2180*100)


#3 

PROMEDIO_DINERO <-select(Lab1, CREDITO, Q) %>% group_by(CREDITO) %>% summarise(PROMEDIODI = mean(Q))
PROMEDIO_POR_CANTIDAD <- select(Lab1, CREDITO, CANTIDAD) %>% group_by(CREDITO) %>% summarise(PROMEDIOCANTIDAD = mean(CANTIDAD))

PROMEDIO  <- merge(PROMEDIO_POR_CANTIDAD, PROMEDIO_DINERO, by = "CREDITO")

PEDIDOS <- select(Lab1, FECHA1, CLIENTE) %>% group_by(CLIENTE) %>% summarise(PEIDIDOS = length(FECHA1))

#1 
trabajadores <- select(Lab1, PILOTO) %>%  group_by(PILOTO) %>% summarise(VIAJES = length(PILOTO))
VIAJES_DIARIOSS <- select(Lab1,PILOTO, FECHA1) %>% group_by(FECHA1) %>% summarise(cantidaddeviajespor = length(FECHA1)/9)
PROMEDIO_DIARIO_POR_PILOTO <- mean(VIAJES_DIARIOSS$cantidaddeviajespor)



#7

library("plotly")
MEJORPILOTO <- plot_ly(trabajadores, x = ~PILOTO, y = ~VIAJES, type = 'bar', name = 'MEJOR PILOTO')
MEJORTRANSPORTE <-barplot(CAMIONES)

