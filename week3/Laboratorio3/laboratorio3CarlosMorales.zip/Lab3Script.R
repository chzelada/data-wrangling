#despacho a cliente: orden habitual
#faltante: viajes inesperados, que la empresa se queda sin producto y pide


library(readxl)
Lab1 <- read_excel("Lab1.xlsx")
head(Lab1)

install.packages("dplyr")
library(dplyr)
select(Lab1, PILOTO)

install.packages("ggplot2")
library(ggplot2)

# debemos contratar m�s personal? m�s veh�culos? cu�ntos y de que tipo
pilotos <- Lab1 %>% count(PILOTO, sort = TRUE)
pilotos

pilotosCamiongrande <-Lab1 %>%
    filter(UNIDAD=="Camion Grande") %>%
    count(PILOTO)%>%
    group_by(PILOTO)

pilotosCamionpeque <-Lab1 %>%
    filter(UNIDAD=="Camion Peque�o") %>%
    count(PILOTO)%>%
    group_by(PILOTO)

pilotosPanel <-Lab1 %>%
    filter(UNIDAD=="Panel") %>%
    count(PILOTO)%>%
    group_by(PILOTO)

pilotos <- Lab1  %>% arrange (PILOTO) %>% distinct(PILOTO)

pilotos <- pilotos %>%
    mutate(CamionGrande = pilotosCamiongrande$n)
pilotos <- pilotos %>%
    mutate(CamionPeque�o = pilotosCamionpeque$n)
pilotos <- pilotos %>%
    mutate(Panel = pilotosPanel$n)
pilotos <- pilotos %>%
    mutate(Total = pilotosCamiongrande$n+pilotosCamionpeque$n+pilotosPanel$n)
pilotos <- pilotos  %>% arrange (desc(Total))

pilotos

totalcamiongrande <- sum(pilotosCamiongrande$n)
totalcamionpeque <- sum(pilotosCamionpeque$n)
totalpanel <- sum(pilotosPanel$n)
totalcamiongrande
totalcamionpeque
totalpanel

CamionGrande <- Lab1 %>%
    filter(UNIDAD=="Camion Grande") %>%
    count(UNIDAD)
CamionGrande   

CamionPeque <- Lab1 %>%
    filter(UNIDAD=="Camion Peque�o") %>%
    count(UNIDAD)
CamionPeque

Panel <- Lab1 %>%
    filter(UNIDAD=="Panel") %>%
    count(UNIDAD)
Panel

#las tarifas actuales son aceptables?

tarifas <-Lab1 %>%
    group_by(Fecha)%>%
    summarise(Total = sum(Q))
    
tarifas


graficaTarifas <- ggplot(tarifas, aes(x=Fecha, y=Total))+ geom_point()
plot(graficaTarifas)

head(Lab1)
#verificar si alguno est� robando
Robando <- Lab1 %>%
    mutate(Test = CANTIDAD/Q) %>%
    filter((Test < 4) && (Test>4))
CantidadRobos<-count(Robando)    
CantidadRobos

# Acciones a tomar

    
head(Lab1)

credito90 <- Lab1 %>% 
    filter(CREDITO==90) %>% 
    count()

credito60 <- Lab1 %>% 
    filter(CREDITO==60) %>% 
    count()

credito30 <- Lab1 %>% 
    filter(CREDITO==30) %>% 
    count()

creditos <- credito30+credito60+credito90

creditos
credito90
credito60
credito30


#pareto
install.packages("qcc");
library(qcc)
Lab2 <- read_excel("Lab1Limpio.xlsx")
head(Lab2)

Clientes <- Lab2 %>%
    group_by(CLIENTE)%>%
    summarise(Total = sum(Q))    

attach(Clientes)
names(Clientes)
Tipo <- Total
names(Tipo) <- CLIENTE
Tabla <- pareto.chart(Tipo)
Tabla



PilotosPareto <- pilotos

attach(PilotosPareto)
names(PilotosPareto)
Tipo2 <- Total
names(Tipo2) <- PILOTO
Tabla2 <- pareto.chart(Tipo2)
Tabla2


