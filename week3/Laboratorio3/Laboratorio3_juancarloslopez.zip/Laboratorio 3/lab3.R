install.packages("rmarkdown")
install.packages("stringr")
install.packages("stringi")
install.packages("plotly")
install.packages("plotrix")
install.packages("forcats")
install.packages("ggplot")
install.packages("ggplot2")
library(ggplot2)
library(ggplot)
library(forcats) 
library(rmarkdown)
library(dplyr)
library(stringr)
library(stringi)
library(tidyr)
library(plotly)
library(plotrix)

Lab1 <- read.csv("~/Lab1.csv")
Lab1 <- Lab1[-c(1)]

#PREGUNTA 1 Mas personal
personal <- Lab1 %>%
  group_by(PILOTO) %>%
  summarise(freq=n())
ganancias <- Lab1 %>%
  group_by(PILOTO)%>%
  summarise(sum(Q))
persgan <- merge(personal, ganancias, by="PILOTO")
colnames(persgan)[3] <- "GANANCIAS"
persgan <- transform(persgan, AVRG=GANANCIAS/freq)
persgan[4] <-  round(persgan[4], 2)
##SI SE COMPRAN MAS CAMIONES SI SE DEBE CONTRATAR MAS PERSONAL PERO SI NO, NO 
##YA QUE INVERTIR EN MAS PERSONAL SIN INVERTIR EN MAS CAMIONES CREARA PERSONAL SIN
##HACER VIAJES DEBIDO A POCA DISPONIBILIDAD DE VEHICULOS 

#PREGUNTA 2 Vehiculos
vehiculos <- Lab1 %>%
  group_by(UNIDAD)%>%
  summarise(Ganancias=sum(Q))
vehiculos2 <- Lab1 %>%
  group_by(UNIDAD)%>%
  count(UNIDAD)
unidades <- merge(vehiculos,vehiculos2, by="UNIDAD")
unidades <- transform(unidades, AVRG=Ganancias/n)
unidades[4] <- round(unidades[4], 2)
pilvehic <- Lab1%>%
  select(UNIDAD, PILOTO)%>%
  group_by(PILOTO)%>%
  count(UNIDAD)
##RESPUESTA: HAY QUE INVERTIR EN CAMION GRANDE YA QUE EN PROMEDIO ES EL QUE DA MAS DINERO Y 
##MAS VIAJES TIENE Y CON VARIOS DE ESOS SE PODRIAN REALIZAR MAS VIAJES Y MEJORAR TIEMPOS
##DE ENTREGA O HACER MAS VIAJES, VARIOS VIAJES AL MISMO TIEMPO
## SE DEBE COMPRAR 1 CAMION GRANDE MAS PARA EQUILIBRAR LOS VIAJES 


#PREGUNTA 3 Tarifas Cliente
clientesdiv <- Lab1%>%
  select(CLIENTE)
clientesdiv$new.col <- mutate_all(clientesdiv, funs(stri_extract_last_words))
clientes <- merge(Lab1, clientesdiv, by="CLIENTE")
clientes <- clientes %>%
  separate(CLIENTE, c("CLIENTE", "ESTADO"), "/")
names(clientes)[11]<-paste("ESTADO2")
clientes[, 11][clientes[, 11] == "OFICINA"] <- NA
clientes[, 11][clientes[, 11] == "AMERICAS"] <- NA
clientes[, 11][clientes[, 11] == "CHINITO"] <- NA
clientes[, 11][clientes[, 11] == "LABS"] <- NA
clientes[, 11][clientes[, 11] == "cliente"] <- NA
clientes[, 11][clientes[, 11] == "Faltante"] <- "FALTANTE"
clientes <- unite_(clientes, "ESTADO", c("ESTADO","ESTADO2"))
clientes[, 2][clientes[, 2] == "NA_NA"] <- NA
clientes[, 2][clientes[, 2] == "NA_FALTANTE"] <- "FALTANTE"
clientes[, 2][clientes[, 2] == "NA_DEVOLUCION"] <- "DEVOLUCION"
clientes[, 2][clientes[, 2] == "Despacho a cliente_NA"] <- "DESPACHADO"
clientes[, 2][clientes[, 2] == "Despacho a cliente |||Faltante_FALTANTE"] <- "DESPACHADO.FALTANTE"
clientes[, 2][clientes[, 2] == " Despacho a cliente_NA"] <- "DESPACHADO"
clientes[, 2][clientes[, 2] == " Despacho a cliente _NA"] <- "DESPACHADO"
clientes[, 1][clientes[, 1] == "CHICHARRONERIA EL RICO COLESTEROL |||Faltante"] <- "CHICHARRONERIA EL RICO COLESTEROL"
clientes[, 1][clientes[, 1] == "EL GALLO NEGRO |||DEVOLUCION"] <- "EL GALLO NEGRO"
clientes[, 1][clientes[, 1] == "EL PINCHE OBELISCO |||Faltante"] <- "EL PINCHE OBELISCO"
clientes[, 1][clientes[, 1] == "POLLO PINULITO|||FALTANTE"] <- "POLLO PINULITO"
clientes[, 1][clientes[, 1] == "TAQUERIA EL CHINITO |||Faltante"] <- "TAQUERIA EL CHINITO"
clientes[, 1][clientes[, 1] == "UBIQUO LABS |||FALTANTE"] <- "UBIQUO LABS"
clientes[, 1][clientes[, 1] == "EL PINCHE OBELISCO "] <- "EL PINCHE OBELISCO"
clientes[, 1][clientes[, 1] == "EL GALLO NEGRO "] <- "EL GALLO NEGRO"
Qclientes <- clientes %>%
  select(CLIENTE, Q)%>%
  group_by(CLIENTE)%>%
  summarise(Q=sum(Q))
Credclientes <- clientes%>%
  select(CLIENTE, CREDITO)%>%
  group_by(CLIENTE)%>%
  count(CREDITO)
devolucion <- subset(clientes, clientes$ESTADO=="DEVOLUCION")
devolucion <- devolucion%>%
  select(CLIENTE, ESTADO)%>%
  group_by(CLIENTE)%>%
  count(CLIENTE)
##LAS TARIFAS ACTUALES SON ACEPTABLES POR LOS CLIENTES MENOS POR EL GALLO NEGRO YA QUE HA SIDO EL QUE CONTIENE MAS DEVOLUCIONES
#PREGUNTA 4 Robo Pilotos
robo1 <- clientes%>%
  select(PILOTO, ESTADO)%>%
  group_by(PILOTO)%>%
  count(ESTADO)
robo2 <- clientes%>%
  select(PILOTO, ESTADO, Q)%>%
  group_by(ESTADO)%>%
  summarise(SUMAS=sum(Q))
robo3 <- clientes%>%
  select(ESTADO)%>%
  group_by(ESTADO)%>%
  count(ESTADO)
robo0 <- merge(robo2, robo3, by="ESTADO")
robo <- robo0%>%
  group_by(ESTADO)%>%
  summarise(AVRG=(SUMAS/n))
##SI NOS ESTAN ROBANDO YA QUE HAY BASTANTE DINERO DEL CUAL NO SE TIENE EL ESTADO YA SEA
##FALTANTE, DEPACHADO, ETC. Y ES CONSTANTE EN TODOS LOS PILOTOS, TIENEN UNA COLUMNA DE 
##DINERO EN LA CUAL NO SE SABE QUE PASO CON EL 

#PARTE VISUAL PARETO 80-20
importantes <- clientes%>%
  select(CLIENTE, Q, CREDITO)%>%
  group_by(CREDITO, CLIENTE)%>%
  summarise(TOTAL=sum(Q))
importantestotal <- importantes[c(2,3)]
importantestotal <- importantestotal%>%
  select(CLIENTE, TOTAL)%>%
  group_by(CLIENTE)%>%
  summarise(TOTAL=sum(TOTAL))
totalfinal <- sum(importantestotal$TOTAL)
importantestotal$PROM <- with(importantestotal, round(((TOTAL/totalfinal)*100), digits=2))
importantestotal <- importantestotal[rev(order(importantestotal$PROM)),]

importantes30 <- subset(importantes, CREDITO==30)
total30 <- sum(importantes30$TOTAL)
importantes30$PROM <- with(importantes30, round(((TOTAL/total30)*100), digits=2))
importantes30 <- importantes30[rev(order(importantes30$PROM)),]
importantes60 <- subset(importantes, CREDITO==60)
total60 <- sum(importantes60$TOTAL)
importantes60$PROM <- with(importantes60, round(((TOTAL/total60)*100), digits=2))
importantes60 <- importantes60[rev(order(importantes60$PROM)),]
importantes90 <- subset(importantes, CREDITO==90)
total90 <- sum(importantes90$TOTAL)
importantes90$PROM <- with(importantes90, round(((TOTAL/total90)*100), digits=2))
importantes90 <- importantes90[rev(order(importantes90$PROM)),]
importantestotalplot <- importantestotal[c(1,3)]
importantes30plot <- importantes30[c(2,4)]
importantes60plot <- importantes60[c(2,4)]
importantes90plot <- importantes90[c(2,4)]

importantes30plot$CLIENTE <- paste(importantes30plot$CLIENTE, importantes30plot$PROM)
importantes30plot$CLIENTE <- paste(importantes30plot$CLIENTE,"%",sep="")
pie(importantes30plot$PROM,labels = importantes30plot$CLIENTE, col=rainbow(length(importantes30plot$CLIENTE)),
    main="% de aporte por cliente 30dias") 
importantes60plot$CLIENTE <- paste(importantes60plot$CLIENTE, importantes60plot$PROM)
importantes60plot$CLIENTE <- paste(importantes60plot$CLIENTE,"%",sep="")
pie(importantes60plot$PROM,labels = importantes60plot$CLIENTE, col=rainbow(length(importantes60plot$CLIENTE)),
    main="% de aporte por cliente 60dias") 
importantes90plot$CLIENTE <- paste(importantes90plot$CLIENTE, importantes90plot$PROM)
importantes90plot$CLIENTE <- paste(importantes90plot$CLIENTE,"%",sep="")
pie(importantes90plot$PROM,labels = importantes90plot$CLIENTE, col=rainbow(length(importantes90plot$CLIENTE)),
    main="% de aporte por cliente 90dias") 
importantestotalplot$CLIENTE <- paste(importantestotalplot$CLIENTE, importantestotalplot$PROM)
importantestotalplot$CLIENTE <- paste(importantestotalplot$CLIENTE,"%",sep="")
pie(importantestotalplot$PROM,labels = importantestotalplot$CLIENTE, col=rainbow(length(importantestotalplot$CLIENTE)),
    main="% de aporte por cliente") 

#MEJORES PILOTOS
robopil <- clientes%>%
  select(PILOTO, ESTADO, Q)%>%
  group_by(PILOTO, ESTADO)%>%
  summarise(SUMAS=sum(Q))
ganancias <- clientes%>%
  select(PILOTO,Q)%>%
  group_by(PILOTO)%>%
  summarise(Q=sum(Q))
robopil$ESTADO <- fct_explicit_na(robopil$ESTADO, na_level = "Vacio")
vacio <- subset(robopil, ESTADO=="Vacio")
pilganrob <- merge(ganancias, vacio, by="PILOTO")
pilganrob <- pilganrob%>%
  select(PILOTO,SUMAS,Q)%>%
  group_by(PILOTO)%>%
  summarise(PROM=SUMAS/Q)
pilganrob$PROM <- round(pilganrob$PROM,digits = 2)
pilotostotal <- merge(pilganrob,persgan, by="PILOTO")
pilotostotal <- pilotostotal[c(1,2,4)]
pilotostotal$ROBO <- with(pilotostotal, round(PROM*GANANCIAS, digits = 2))
pilotostotal$TOTAL <- with(pilotostotal, GANANCIAS-ROBO)
pilotostotal <- pilotostotal[rev(order(pilotostotal$TOTAL)),]
pilotostotal <- pilotostotal[-c(2)]
p<-ggplot(data=pilotostotal, aes(x=PILOTO, y=GANANCIAS)) +
  geom_bar(stat="identity", width=0.5, color="blue", fill="white") +
  geom_text(aes(label=GANANCIAS), vjust=-0.3, size=3.5) + ylim(0, 110000)
p
p2<-ggplot(data=pilotostotal, aes(x=PILOTO, y=ROBO)) +
  geom_bar(stat="identity", width=0.5, color="blue", fill="white") +
  geom_text(aes(label=ROBO), vjust=-0.3, size=3.5) + ylim(0, 35000)
p2
p3<-ggplot(data=pilotostotal, aes(x=PILOTO, y=TOTAL)) +
  geom_bar(stat="identity", width=0.5, color="blue", fill="white") +
  geom_text(aes(label=TOTAL), vjust=-0.3, size=3.5) + ylim(0, 110000)
p3

v<-ggplot(data=vehiculos, aes(x=UNIDAD, y=Ganancias)) +
  geom_bar(stat="identity", width=0.5, color="blue", fill="white") +
  geom_text(aes(label=Ganancias), vjust=-0.3, size=3.5) 
v
v2<-ggplot(data=vehiculos2, aes(x=UNIDAD, y=n)) +
  geom_bar(stat="identity", width=0.5, color="blue", fill="white") +
  geom_text(aes(label=n), vjust=-0.3, size=3.5) 
v2
totalfff <- sum(Lab1$Q)
